package com.example.geethu_u.androidgeofence.utils;

/**
 * Created by Geethu_U on 12/23/2015.
 */
public class FragmentsTags {
    public static String ADD_SCREEN = "Add Screen Tag";

}

